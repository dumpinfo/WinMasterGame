Compilation Instructions

To compile TEXTDEMO.CPP you will need:

1. A Win32 Compiler such as MS VC++ 5.0.
2. The DirectX 5.0 SDK, you can get this from MS at www.microsoft.com/directx/default.asp

Create a Win32 Application and include:

1. TMAPDEMO.CPP -  The main program.
2. TMAPPER.CPP,H - The texture mapper and header.
3. DDRAW.LIB - The DirectDraw import library from the DirectX SDK.
4. WINMM.LIB - The MS Multimedia Library.

That's about it, and it should compile, link, and run. 

Lord Necron

Necron@slip.net
