Dear Production,

Included in this archive TMAPPROD.ZIP is everything you need
for the article including the listing source for Listings 2,3, and 4.

Also, the other file TMAPSRC.ZIP contains all the source and demos and 
should be left as is and placed on your site with the FTP URL referenced
at the end of the article (there is a production call out for you).

Thanks,


Andre' LaMothe
408.945.9495
necron@slip.net
